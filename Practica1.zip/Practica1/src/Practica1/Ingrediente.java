package Practica1;
import java.util.LinkedList;
import java.util.List;

public class Ingrediente {

	public String nombre;
	
	public Ingrediente(String nombre) {
		this.nombre = nombre;		
	}

}
