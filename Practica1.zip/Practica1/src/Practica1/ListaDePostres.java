package Practica1;
import java.util.LinkedList;
import java.util.List;

	public class ListaDePostres {
	List<Postre> postres;
	
    public ListaDePostres() {
        this.postres = new LinkedList<>();
    }

    // Agrega un nuevo postre a la lista
    public void agregarPostre(String nombrePostre) {
        Postre nuevoPostre = new Postre(nombrePostre);
        postres.add(nuevoPostre);
    }

    // Busca un postre por su nombre y devuelve su referencia
    private Postre buscarPostre(String nombrePostre) {
        for (Postre postre : postres) {
            if (postre.nombre.equalsIgnoreCase(nombrePostre)) {
                return postre;
            }
        }
        return null;
    }

    // Imprime todos los postres y sus ingredientes
    public void listarPostres() {
        System.out.println("Listado de postres:");
        for (Postre postre : postres) {
            System.out.println(postre.nombre);
        }
    }

    // Método principal
    public static void main(String[] args) {
        ListaDePostres listaDePostres = new ListaDePostres();

        // Ejemplos de uso
        listaDePostres.agregarPostre("Tiramisu");
        listaDePostres.agregarPostre("Cheesecake");

        // Agregar ingredientes a un postre
        listaDePostres.buscarPostre("Tiramisu").agregarIngrediente("Café");
        listaDePostres.buscarPostre("Cheesecake").agregarIngrediente("Queso crema");

        // Imprimir ingredientes de un postre
        listaDePostres.buscarPostre("Tiramisu").imprimirIngredientes();
        listaDePostres.buscarPostre("Cheesecake").imprimirIngredientes();

        // Eliminar ingredientes de un postre
        listaDePostres.buscarPostre("Tiramisu").eliminarIngredientes();

        // Imprimir ingredientes después de eliminarlos
        listaDePostres.buscarPostre("Tiramisu").imprimirIngredientes();

        // Listar todos los postres
        listaDePostres.listarPostres();
    }
}
