package Practica1;
import java.util.LinkedList;
import java.util.List;

	class Postre {
	    String nombre;
	    List<Ingrediente> ingredientes;

	    public Postre(String nombre) {
	        this.nombre = nombre;
	        this.ingredientes = new LinkedList<>();
	    }

	    // Agrega un nuevo ingrediente al postre
	    public void agregarIngrediente(String nombreIngrediente) {
	        Ingrediente nuevoIngrediente = new Ingrediente(nombreIngrediente);
	        ingredientes.add(nuevoIngrediente);
	    }

	    // Imprime todos los ingredientes del postre
	    public void imprimirIngredientes() {
	        System.out.println("Ingredientes de " + nombre + ":");
	        for (Ingrediente ingrediente : ingredientes) {
	            System.out.println("- " + ingrediente.nombre);
	        }
	    }

	    // Elimina todos los ingredientes del postre
	    public void eliminarIngredientes() {
	        ingredientes.clear();
	    }
}
