package Practica1;

public class Scanner {

	public char nextInt() {
		// TODO Auto-generated method stub
		return 0;
	}

}
