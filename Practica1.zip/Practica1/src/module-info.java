/**
 * 
 */
/**
 * @author leand
 *
 */
module Practica1 {
}